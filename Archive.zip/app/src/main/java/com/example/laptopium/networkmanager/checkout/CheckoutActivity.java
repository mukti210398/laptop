package com.example.laptopium.networkmanager.checkout;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.laptopium.R;

public class CheckoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
    }
}