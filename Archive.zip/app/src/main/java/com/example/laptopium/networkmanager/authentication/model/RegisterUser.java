package com.example.laptopium.networkmanager.authentication.model;

import java.io.Serializable;

public class RegisterUser implements Serializable {
    private String userMail;
    private String userPswd;
    private String userName;
    private String userImage;


    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMail() {
        return userMail;
    }

    public void setUserMail(String userMail) {
        this.userMail = userMail;
    }

    public String getUserPswd() {
        return userPswd;
    }

    public void setUserPswd(String userPswd) {
        this.userPswd = userPswd;
    }

    public RegisterUser() {
    }
}
