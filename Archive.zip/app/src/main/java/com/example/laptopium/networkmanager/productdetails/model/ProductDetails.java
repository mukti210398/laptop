package com.example.laptopium.networkmanager.productdetails.model;

public class ProductDetails{
	private String product;
	private String memory;
	private double merchantProductRating;
	private String typeName;
	private String weight;
	private String gpu;
	private double inches;
	private Object merchantId;
	private int price;
	private String imageUrl;
	private String company;
	private String id;
	private String screenResolution;
	private String opSys;
	private String ram;

	public void setProduct(String product){
		this.product = product;
	}

	public String getProduct(){
		return product;
	}

	public void setMemory(String memory){
		this.memory = memory;
	}

	public String getMemory(){
		return memory;
	}

	public void setMerchantProductRating(double merchantProductRating){
		this.merchantProductRating = merchantProductRating;
	}

	public double getMerchantProductRating(){
		return merchantProductRating;
	}

	public void setTypeName(String typeName){
		this.typeName = typeName;
	}

	public String getTypeName(){
		return typeName;
	}

	public void setWeight(String weight){
		this.weight = weight;
	}

	public String getWeight(){
		return weight;
	}

	public void setGpu(String gpu){
		this.gpu = gpu;
	}

	public String getGpu(){
		return gpu;
	}

	public void setInches(double inches){
		this.inches = inches;
	}

	public double getInches(){
		return inches;
	}

	public void setMerchantId(Object merchantId){
		this.merchantId = merchantId;
	}

	public Object getMerchantId(){
		return merchantId;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public int getPrice(){
		return price;
	}

	public void setImageUrl(String imageUrl){
		this.imageUrl = imageUrl;
	}

	public String getImageUrl(){
		return imageUrl;
	}

	public void setCompany(String company){
		this.company = company;
	}

	public String getCompany(){
		return company;
	}

	public void setId(String id){
		this.id = id;
	}

	public String getId(){
		return id;
	}

	public void setScreenResolution(String screenResolution){
		this.screenResolution = screenResolution;
	}

	public String getScreenResolution(){
		return screenResolution;
	}

	public void setOpSys(String opSys){
		this.opSys = opSys;
	}

	public String getOpSys(){
		return opSys;
	}

	public void setRam(String ram){
		this.ram = ram;
	}

	public String getRam(){
		return ram;
	}

	@Override
 	public String toString(){
		return 
			"ProductDetails{" + 
			"product = '" + product + '\'' + 
			",memory = '" + memory + '\'' + 
			",merchantProductRating = '" + merchantProductRating + '\'' + 
			",typeName = '" + typeName + '\'' + 
			",weight = '" + weight + '\'' + 
			",gpu = '" + gpu + '\'' + 
			",inches = '" + inches + '\'' + 
			",merchantId = '" + merchantId + '\'' + 
			",price = '" + price + '\'' + 
			",imageUrl = '" + imageUrl + '\'' + 
			",company = '" + company + '\'' + 
			",id = '" + id + '\'' + 
			",screenResolution = '" + screenResolution + '\'' + 
			",opSys = '" + opSys + '\'' + 
			",ram = '" + ram + '\'' + 
			"}";
		}
}
