package com.example.laptopium.networkmanager.authentication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.laptopium.R;
import com.example.laptopium.networkmanager.authentication.model.LoginUser;
import com.example.laptopium.networkmanager.authentication.network.IAuthentication;
import com.example.laptopium.networkmanager.authentication.retrofitbuilder.RetrofitBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(R.id.btn_login_login).setOnClickListener(view->
        {
            verifyLogin();
        });
        findViewById(R.id.btn_login_reg).setOnClickListener(view->
        {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    private void verifyLogin() {
        EditText et_login = findViewById(R.id.et_login_mail);
        String str_mail = et_login.getText().toString();
        EditText et_password = findViewById(R.id.et_login_password);
        String str_password = et_password.getText().toString();
        Log.d("Mukti", "verifyLogin: "+str_mail+"  " + str_password);
        Retrofit retrofit = RetrofitBuilder.getInstance();
        IAuthentication iAuthentication = retrofit.create(IAuthentication.class);
        Call<Boolean> loginUserCall = iAuthentication.sendLoginDetails(new LoginUser(str_mail,str_password));
        Log.d("Mukti", "verifyLogin: ");
        Callback<Boolean> callback = new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if(response.body() == true) {
                    SharedPreferences sharedPreferences = getSharedPreferences("com.example.laptopium", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("userMail", str_mail);
                    editor.putString("isLoggedIn","true");
                    //editor.putString("userName", response.body().getUserName());
                    editor.apply();
                    Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                    startActivity(intent);
                    //Toast.makeText(LoginActivity.this, "Opps!! Something went wrong.\n Try again.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(LoginActivity.this, "Invalid Credentials.\n Try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                Toast.makeText(LoginActivity.this, "Opps!! Something went wrong.\n Try again.", Toast.LENGTH_SHORT).show();
            }
        };
        loginUserCall.enqueue(callback);
    }

}