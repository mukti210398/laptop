package com.example.laptopium.networkmanager.category;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.example.laptopium.R;
import com.example.laptopium.networkmanager.category.model.CategoryList;
import com.example.laptopium.networkmanager.category.network.ICategoryApi;
import com.example.laptopium.networkmanager.productdetails.retrofitbuilder.RetrofitBuilder;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
    }




    // Display all categories
    private void setCategoryList() {
        Retrofit retrofit = RetrofitBuilder.getInstance();
        ICategoryApi iCategory = retrofit.create(ICategoryApi.class);
        Call<List<CategoryList>> categoryList = iCategory.getCategoryList();
        Callback<List<CategoryList>> callback = new Callback<List<CategoryList>>() {
            @Override
            public void onResponse(Call<List<CategoryList>> call, Response<List<CategoryList>> response) {
                TextView tv_category_name = findViewById(R.id.tv_category_name);
               // tv_category_name.setText(response.body().getCategory());
            }

            @Override
            public void onFailure(Call<List<CategoryList>> call, Throwable t) {

            }
        };
        categoryList.enqueue(callback);
    }
}