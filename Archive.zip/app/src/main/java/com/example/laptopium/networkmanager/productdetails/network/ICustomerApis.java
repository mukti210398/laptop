package com.example.laptopium.networkmanager.productdetails.network;


import com.example.laptopium.networkmanager.productdetails.model.ProductDetails;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ICustomerApis {
    @GET("/product/{productId}")
    Call<ProductDetails> getProductDetails(@Path("productId") String productId);
}
