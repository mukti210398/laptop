package com.example.laptopium.networkmanager.authentication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.laptopium.R;
import com.example.laptopium.networkmanager.authentication.model.UserDetails;
import com.example.laptopium.networkmanager.authentication.network.IAuthentication;
import com.example.laptopium.networkmanager.authentication.retrofitbuilder.RetrofitBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.laptopium", Context.MODE_PRIVATE);
        if(sharedPreferences.getString("userMail",null)!=null)
        {
            if("true".equals(sharedPreferences.getString("isLoggedIn",null)))
            {
                String email = sharedPreferences.getString("userMail","null");
                Retrofit retrofit = RetrofitBuilder.getInstance();
                IAuthentication iAuthentication = retrofit.create(IAuthentication.class);
                Call<UserDetails> userDetailsCall  = iAuthentication.getUserDetails(email);
                userDetailsCall.enqueue(new Callback<UserDetails>() {
                    @Override
                    public void onResponse(Call<UserDetails> call, Response<UserDetails> response) {
                        EditText et_name = findViewById(R.id.et_profile_edit_name);
                        et_name.setText(response.body().getUserName());
                        EditText et_email = findViewById(R.id.et_profile_email_edit);
                        et_email.setText(response.body().getUserMail());
                        ImageView iv_profile = findViewById(R.id.iv_profile_image);
                        Glide.with(ProfileActivity.this)
                                .load(response.body().getUserImageUrl())
                                .into(iv_profile);
                    }

                    @Override
                    public void onFailure(Call<UserDetails> call, Throwable t) {

                    }
                });
            }

        }
        {

        }
    }


}