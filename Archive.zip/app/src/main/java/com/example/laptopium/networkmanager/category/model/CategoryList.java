package com.example.laptopium.networkmanager.category.model;

public class CategoryList {
}
