package com.example.laptopium.networkmanager.productdetails;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.laptopium.R;
import com.example.laptopium.networkmanager.productdetails.network.ICustomerApis;
import com.example.laptopium.networkmanager.productdetails.model.ProductDetails;
import com.example.laptopium.networkmanager.productdetails.retrofitbuilder.RetrofitBuilder;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ProductDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = (CollapsingToolbarLayout) findViewById(R.id.toolbar_layout);
        toolBarLayout.setTitle(getTitle());

        setProductDetails();



    }
// Display specific product detials
    private void setProductDetails() {
        Retrofit retrofit = RetrofitBuilder.getInstance();
        ICustomerApis iCustomerApis = retrofit.create(ICustomerApis.class);
        Call<ProductDetails> productDetails = iCustomerApis.getProductDetails("6001672fdfed1322fde9e893");

        Callback<ProductDetails> callback = new Callback<ProductDetails>() {
            @Override
            public void onResponse(Call<ProductDetails> call, Response<ProductDetails> response) {
                TextView tv_product_name = findViewById(R.id.tv_product_details_product_name);
                TextView tv_product_category = findViewById(R.id.tv_product_details_category);
                TextView tv_product_price = findViewById(R.id.tv_product_details_price);
                TextView tv_product_type = findViewById(R.id.tv_product_details_typeName);
                TextView tv_product_attributes = findViewById(R.id.tv_product_details_more_attributes);
                ImageView iv_product_image = findViewById(R.id.iv_product_details_product_image);
                tv_product_name.setText(response.body().getProduct().toString());
                tv_product_type.setText(response.body().getTypeName().toString());
                tv_product_category.setText(response.body().getCompany().toString());
                //tv_product_price.setText(response.body().gets);
                Glide.with(ProductDetailsActivity.this)
                        .load(response.body().getImageUrl())
                        .into(iv_product_image);
            }

            @Override
            public void onFailure(Call<ProductDetails> call, Throwable t) {

            }
        };
        productDetails.enqueue(callback);
    }
}
