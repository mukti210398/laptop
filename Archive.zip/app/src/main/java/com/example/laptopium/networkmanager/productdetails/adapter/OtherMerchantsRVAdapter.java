//package com.example.laptopium.networkmanager.productdetails.adapter;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.example.laptopium.R;
//import com.example.laptopium.networkmanager.productdetails.model.OtherMerchants;
//
//import java.util.List;
//
//
//public class OtherMerchantsRVAdapter  extends RecyclerView.Adapter<OtherMerchantsRVAdapter.ViewHolder> {
//
//    public static class ViewHolder extends RecyclerView.ViewHolder {
//        private final TextView tv_other_merchant_details;
//        private final TextView tv_other_merchant_price;
//        private final View rootView;
//       //private final TextView tv_emp_lname;
//
//        public ViewHolder(View view) {
//            super(view);
//            rootView = view;
//            tv_other_merchant_details = view.findViewById(R.id.tv_other_merchant_details);
//            tv_other_merchant_price = view.findViewById(R.id.tv_other_merchant_price);
//        }
//
//    }
//
//        private final List<OtherMerchants> otherMerchantsList;
//        //private final IEmployeeDataInterface mEmployeeDataInterface;
//
//        public OtherMerchantsRVAdapter(List<OtherMerchants> otherMerchantsList, IEmployeeDataInterface mEmployeeDataInterface) {
//            this.otherMerchantsList = otherMerchantsList;
//            //this.mEmployeeDataInterface = mEmployeeDataInterface;
//        }
//
//        @NonNull
//        @Override
//        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//            View view = LayoutInflater.from(parent.getContext())
//                    .inflate(R.layout.card_show_other_merchants, parent, false);
//            return new ViewHolder(view);
//        }
//
//        @Override
//        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
//            OtherMerchants otherMerchants = otherMerchantsList.get(position);
//            holder.tv_other_merchant_details.setText("ID : "+ String.valueOf(otherMerchants.getM));
//            holder.tv_other_merchant_price.setText("User ID : "+ String.valueOf(otherMerchants.getFirstName()));
//            //holder.tv_emp_lname.setText("Title : "+myEmployee.getLastName());
//            holder.rootView.setOnClickListener((view -> mEmployeeDataInterface.onUserClick(myEmployee)));
//        }
//
//        @Override
//        public int getItemCount() {
//            return o.size();
//        }
//
//        public interface IEmployeeDataInterface {
//            void onUserClick(Employee employee);
//
//            void onUserClickDel(Employee employee);
//        }
//        public interface IEmployeeAdd{
//            void onAddUser(Employee employee);
//        }
//
//
//
//
//
//    }
//}
