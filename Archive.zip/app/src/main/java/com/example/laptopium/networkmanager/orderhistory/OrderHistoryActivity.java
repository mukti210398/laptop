package com.example.laptopium.networkmanager.orderhistory;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.laptopium.R;

public class OrderHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
    }
}