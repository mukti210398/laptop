package com.example.laptopium.networkmanager.authentication.model;

import com.google.gson.annotations.SerializedName;

public class RegisterString{

	@SerializedName("str")
	private String str;

	public void setStr(String str){
		this.str = str;
	}

	public String getStr(){
		return str;
	}

	@Override
 	public String toString(){
		return 
			"RegisterString{" + 
			"str = '" + str + '\'' + 
			"}";
		}
}