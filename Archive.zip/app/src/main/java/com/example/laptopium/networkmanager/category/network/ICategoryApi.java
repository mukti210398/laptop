package com.example.laptopium.networkmanager.category.network;

import com.example.laptopium.networkmanager.category.model.CategoryList;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ICategoryApi {
    @GET("/product/findCategory")
    Call<List<CategoryList>> getCategoryList();
}
